sap.ui.define([
	"syncc15/ui5.basic.hw2/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
