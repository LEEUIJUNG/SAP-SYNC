sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("sync.c15.ui5.basic.hw2.controller.Main", {
        onInit() {
        },

        onPress(oEvent) {
            var oSelectedItem = oEvent.getSource();
            var oContext = oSelectedItem.getBindingContext('scarr');
            var sPath = oContext.getPath();

            var oRouter = this.getOwnerComponent().getRouter();

            oRouter.navTo(
                "RouteFlight", {
                flight: window.encodeURIComponent(sPath)
            }
            );

        }
    });
});