sap.ui.define([
    "sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel"
], (Controller, JSONModel) => {
    "use strict";

    return Controller.extend("sync.c15.ui5.basic.hw2.controller.Flight", {
        onInit() {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("RouteFlight").attachPatternMatched(this._onObjectMatched, this);
        },

        _onObjectMatched(oEvent) {
            var oArgs = oEvent.getParameter("arguments");
            var sflight = window.decodeURIComponent(oArgs.flight);
            var oModel = this.getOwnerComponent().getModel('scarr');
            var sPath = sflight + "/to_ZSFLIGHT";

            oModel.read(sPath, {

                success: (oData) => {
                    var oNewModel = new JSONModel(oData);
                    this.getView().setModel(oNewModel, "flight");

                    // console.log(this.getView().getModel("flight").getData());
                },
                error: (oError) => {
                    console.error("error가 발생하였습니다. : ", oError);
                }
            });


        }

    });
});