sap.ui.define([
	"syncc15/ui5.basic.hw3/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
