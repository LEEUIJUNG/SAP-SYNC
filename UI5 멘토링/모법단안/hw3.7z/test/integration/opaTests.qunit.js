/* global QUnit */

sap.ui.require(["sync/c15/ui5/basic/hw3/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
