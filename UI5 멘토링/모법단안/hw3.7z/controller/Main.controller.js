sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
], function (Controller, MessageToast) {
    "use strict";

    return Controller.extend("sync.c15.ui5.basic.hw3.controller.Main", {

        onInit() {

        },


        onSave() {
            var oModel = this.getView().getModel("student");

            var sStdid = this.byId("studentId").getValue();
            var sName = this.byId("studentName").getValue();

            var oData = {
                Stdid: sStdid,
                Name: sName
            };


            oModel.create("/StudentC15Set", oData, {
                success: function () {
                    MessageToast.show("생성 성공");
                },
                error: function () {
                    MessageToast.show("생성 실패");
                }
            });
        },
        onEdit: function (oEvent) {
            var oModel = this.getView().getModel("student");
            var oContext = oEvent.getSource().getBindingContext("student");
            var oData = oContext.getObject();

            var sPath = oContext.getPath();
            var oInput = this.getView().byId("idInput");
            var sName = oInput.getValue();


            var oNewData = {
                Stdid: oData.Stdid,
                Name: sName
            };


            oModel.update(sPath, oNewData, {
                success: function () {
                    MessageToast.show("수정 성공");
                },
                error: function () {
                    MessageToast.show("수정 실패");
                }
            });
        },

        onDelete(oEvent) {
            var oModel = this.getView().getModel("student");
            var oContext = oEvent.getSource().getBindingContext("student");
            var sPath = oContext.getPath();

            oModel.remove(sPath, {
                success: function () {
                    MessageToast.show("삭제 성공");
                },
                error: function () {
                    MessageToast.show("삭제 실패");
                }
            });

        }
    });
});
