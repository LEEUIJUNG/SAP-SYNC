sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("sync.c15.ui5.basic.hw3.controller.App", {
      onInit() {
      }
  });
});