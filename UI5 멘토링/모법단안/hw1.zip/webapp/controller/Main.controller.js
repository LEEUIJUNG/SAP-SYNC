sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], (Controller, JSONModel) => {
    "use strict";

    return Controller.extend("lsyn.c15.ui5.basic.hw1.controller.Main", {

        /* 
            const, let, var 의 차이
            var : 재사용이 가능 재할당 가능
            let : 재선언이 안됨 재할당 가능
            const : 재선언 재할당이 안됨

        */
        onInit() {
        },
        // 항공편 테이블의 데이터를 클릭하면 실행되는 메소드
        // oEvent는 실행될떄 발생한 정보를 받아온다.
        onPressTable1(oEvent) {
            // event 가 발생한 ui(control) 을 가져온다.
            let oSelectedItem = oEvent.getSource();

            // 해당 control 에 연결된 Model 정보를 가져온다.
            let oContext = oSelectedItem.getBindingContext("data");

            // Model 경로를 가져온다.
            let sPath = oContext.getPath();

            // 이 경로를 controller 가 연결된 현재 view의 경로로 취급한다.
            let oView = this.getView();
            oView.bindElement({
                path: sPath,
                model: "data"
            });


         },

         
        onPressTable2(oEvent) {
            // event 가 발생한 ui(control) 을 가져온다.
            let oSelectedItem = oEvent.getSource();

            // 해당 control 에 연결된 Model 정보를 가져온다.
            let oContext = oSelectedItem.getBindingContext("data");

            // Model 경로를 가져온다.
            let sPath = oContext.getPath();

            // view 에서 model 객체를 가져온다.
            let oModel = this.getView().getModel("data");

            // to_Carrier 데이터 요청
            // CRUD 중 raed 를 사용하여 경로에 대한 데이터를 받아온다.
            oModel.read(sPath + "/to_Booking", {
                // 데이터 읽기에 성공 했을 경우
                success: (oData) => {
                    // openDialog method 를 실행한다.
                    this.moveRoute(oData);
                },
                error: (oError) => {
                    console.error("error가 발생하였습니다. : ", oError);
                }
            });
        },

        moveRoute(oData) {
            // .getOwnerComponent() 현재 controller가 속한 component를 반환
            // component를 는 component.js 여기서 this.getRouter().initialize(); 라우터를 초기화함
            // component에서 router 를 가지고옴
            const oRouter = this.getOwnerComponent().getRouter();


            // component.js 에 전역 모델로 등록하기 위해 model carr 을 가져온다.
            let oModel = new JSONModel(oData);
            // 다른 view 에서 model 을 사용하기 위해 component의 model 로 다시 등록한다.
            // 이떄 모델의 이름이 같아도 상관이 없다 스코프의 범위가 다르기 떄문이다. 
            // 하지만 이름이 같아서 호출할떄 서로 덮어 씌워 질 수 있기 떄문에 이름을 다르게 해주길 권장
            this.getOwnerComponent().setModel(oModel, "book");
            // router name flight 로 이동
            // manifest.json에 입력한
            /*
                "routes": [
                    {
                            "name": "flight", // 라우터의 이름
                            "pattern": "flight", // 라우터로 이동할때 url 주소
                            "target": "flight" // 이동할 target 이름
                        }
                    ],
                    "targets": {
                        "flight": {
                            "id": "flight", // view 의  id
                            "name": "Flight" // view 의 이름
                        }
                    }
                },
            */
            oRouter.navTo("flight");

        }

    });
});