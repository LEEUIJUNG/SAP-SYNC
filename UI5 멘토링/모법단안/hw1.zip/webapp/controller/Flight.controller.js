sap.ui.define(
  ["sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel"],
  (Controller, JSONModel) => {
    "use strict";

    return Controller.extend("lsyn.c15.ui5.basic.hw1.controller.Flight", {
      onInit() {
        // 처음 view 가 실행될떄 최초 1번만 작동
        // component 에서 전연 model carr2 를 가져온다.
        let oModel = this.getOwnerComponent().getModel("book");
        // 가져온 model 을 binding 한다.
        this.getView().setModel(oModel, "book2");

        // console.log("Model Data:", this.getView().getModel("book2").getProperty("/"));
      },

      async openDialog(oEvent) {
        this.oDialog ??= await this.loadFragment({
          name: "lsyn.c15.ui5.basic.hw1.view.Info",
        });
        // 내가 선택한 행의 정보를 getParameter() 에서 "rowContext" 로 가져온다.
        // rowSelectionChange 의 parameter 참조
        // https://sapui5.hana.ondemand.com/#/api/sap.ui.table.Table%23events/paste
        var oContext = oEvent.getParameter("rowContext");
        // 행의 model 주소를 가져온다.
        var sPath = oContext.getPath();
        // 현재 view에서 사용한 modeld을 받아온다.
        let oModel = this.getView().getModel("book2");
        // 받아온 모델에서, 내가 클릭한 경로에 있는 proerty(해당하는 위치에 있는 필드값들)를 받아온다.
        let oSelectedData = oModel.getProperty(sPath);
        // dialog에 model 을 설정하기 위해 결과 값을 jsonmodel로 만든다.
        // dialog 에 다시 만든 model을 등록한다.
        this.oDialog.setModel(new JSONModel(oSelectedData), "book3");
        this.getView().addDependent(this.oDialog);

        // console.log(oSelectedData);

        this.oDialog.open();

        // // 모델이 잘 binding 되었나 확인
        // // carr 이라는 이름의 model 의 객채를 가져온다.
        // const oDialogModel = this.oDialog.getModel("carr");
        // console.log(oDialogModel); // 모델 출력
        // console.log(oDialogModel.getData()); // 모델의 데이터 출력

        /* getProperty 를 활용하는 방법
                    <Text id="CarridText" />  처럼 model 이 아니라 id 기준으로 값을 직접 넣을 경우
                    var sCarrid = oModel.getProperty("/Carrid");
                    var oCarridText = this.oDialog.byId("CarridText");
                    oCarridText.setText(sCarrid);
                    이런식으로 작성
                    */
      },

      onCloseDialog() {
        this.byId("idDialog").close();
      },
    });
  }
);
