sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("lsyn.c15.ui5.basic.hw1.controller.App", {
      onInit() {
      }
  });
});