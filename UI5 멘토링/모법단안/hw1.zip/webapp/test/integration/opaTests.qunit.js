/* global QUnit */

sap.ui.require(["lsyn/c15/ui5/basic/hw1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
