sap.ui.define([
	"lsync15/ui5.basic.hw1/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
